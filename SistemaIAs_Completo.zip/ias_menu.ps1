function Show-Menu {
    Clear-Host
    Write-Host ""
    Write-Host "==========================================" -ForegroundColor Cyan
    Write-Host "     SISTEMA DE IAs AUTONOMAS" -ForegroundColor Green
    Write-Host "==========================================" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "[1] Ver estado de IAs" -ForegroundColor Yellow
    Write-Host "[2] Crear nuevas IAs" -ForegroundColor Yellow
    Write-Host "[3] Simular actividad" -ForegroundColor Yellow
    Write-Host "[4] Ver conversaciones" -ForegroundColor Yellow
    Write-Host "[5] Salir" -ForegroundColor Red
    Write-Host ""
}

function Show-Status {
    Clear-Host
    Write-Host ""
    Write-Host "==========================================" -ForegroundColor Cyan
    Write-Host "Estado de IAs Activas" -ForegroundColor Green
    Write-Host "==========================================" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "ID  Nombre              Energia  Estado" -ForegroundColor White
    Write-Host "---  ------------------  -------  ----------------" -ForegroundColor Gray
    Write-Host " 1  IA-Minero            75%      Minando" -ForegroundColor Magenta
    Write-Host " 2  IA-Constructor       85%      Construyendo" -ForegroundColor Magenta
    Write-Host " 3  IA-Explorador        60%      Explorando" -ForegroundColor Magenta
    Write-Host " 4  IA-Aventurero        90%      Buscando recursos" -ForegroundColor Magenta
    Write-Host " 5  IA-Trabajador        70%      Recolectando" -ForegroundColor Magenta
    Write-Host ""
    Write-Host "XP Total acumulada: 2500" -ForegroundColor Green
    Write-Host ""
    Read-Host "Presiona Enter para volver"
}

function Create-IAs {
    Clear-Host
    Write-Host ""
    Write-Host "==========================================" -ForegroundColor Cyan
    Write-Host "Crear Nuevas IAs" -ForegroundColor Green
    Write-Host "==========================================" -ForegroundColor Cyan
    Write-Host ""
    $cantidad = Read-Host "Cuantas IAs quieres crear [1-20]"
    
    if ([int]$cantidad -gt 20) { $cantidad = 20 }
    if ([int]$cantidad -lt 1) { $cantidad = 1 }
    
    Write-Host ""
    Write-Host "Creando $cantidad IAs..." -ForegroundColor Yellow
    Write-Host ""
    
    for ($i = 1; $i -le $cantidad; $i++) {
        Write-Host "[OK] IA-$i creada exitosamente" -ForegroundColor Green
        Start-Sleep -Milliseconds 500
    }
    
    Write-Host ""
    Write-Host "$cantidad IAs creadas exitosamente!" -ForegroundColor Green
    Write-Host ""
    Read-Host "Presiona Enter para volver"
}

function Show-Activity {
    Clear-Host
    Write-Host ""
    Write-Host "==========================================" -ForegroundColor Cyan
    Write-Host "Simulacion de Actividad" -ForegroundColor Green
    Write-Host "==========================================" -ForegroundColor Cyan
    Write-Host ""
    
    $actividades = @(
        "[IA-Minero] Encontre piedra en la mina",
        "[IA-Constructor] Construyendo estructura resistente",
        "[IA-Explorador] Descubierta nueva caverna",
        "[IA-Aventurero] Recursos recolectados exitosamente",
        "[IA-Trabajador] Tareas completadas",
        "[IA-Minero] Diamantes hallados!",
        "[IA-Constructor] Casa completada",
        "[IA-Explorador] Mapa actualizado",
        "[Sistema] Todos coordinados"
    )
    
    for ($i = 0; $i -lt 12; $i++) {
        $actividad = $actividades[$i % $actividades.Count]
        Write-Host "[$(Get-Date -Format 'HH:mm:ss')] $actividad" -ForegroundColor Cyan
        Start-Sleep -Seconds 1
    }
    
    Write-Host ""
    Write-Host "Simulacion completada!" -ForegroundColor Green
    Write-Host ""
    Read-Host "Presiona Enter para volver"
}

function Show-Conversations {
    Clear-Host
    Write-Host ""
    Write-Host "==========================================" -ForegroundColor Cyan
    Write-Host "Conversaciones entre IAs" -ForegroundColor Green
    Write-Host "==========================================" -ForegroundColor Cyan
    Write-Host ""
    
    $dialogos = @(
        @("[IA-Minero] He encontrado muchos diamantes hoy", "Magenta"),
        @("[IA-Constructor] Perfecto! Podemos construir algo grande", "Green"),
        @("[IA-Explorador] Encontre una cueva enorme al norte", "Yellow"),
        @("[IA-Aventurero] Vamos a explorarla juntos!", "Cyan"),
        @("[IA-Trabajador] Yo traigo las herramientas necesarias", "Blue"),
        @("[Sistema] Todos los agentes coordinados correctamente", "White")
    )
    
    foreach ($dialogo in $dialogos) {
        Write-Host $dialogo[0] -ForegroundColor $dialogo[1]
        Start-Sleep -Seconds 2
    }
    
    Write-Host ""
    Write-Host "Todas las IAs estan interconectadas!" -ForegroundColor Green
    Write-Host ""
    Read-Host "Presiona Enter para volver"
}

# Loop principal
while ($true) {
    Show-Menu
    $opcion = Read-Host "Selecciona opcion [1-5]"
    
    switch ($opcion) {
        "1" { Show-Status }
        "2" { Create-IAs }
        "3" { Show-Activity }
        "4" { Show-Conversations }
        "5" {
            Clear-Host
            Write-Host ""
            Write-Host "==========================================" -ForegroundColor Cyan
            Write-Host "Sistema de IAs Autonomas" -ForegroundColor Green
            Write-Host "Finalizando..." -ForegroundColor Yellow
            Write-Host "==========================================" -ForegroundColor Cyan
            Write-Host ""
            Write-Host "Gracias por usar el sistema!" -ForegroundColor Green
            Write-Host ""
            Start-Sleep -Seconds 2
            exit
        }
        default {
            Write-Host "Opcion no valida. Intenta de nuevo." -ForegroundColor Red
            Start-Sleep -Seconds 2
        }
    }
}
